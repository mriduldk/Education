$((function(){var e=$("#editPermissionForm");e.length&&e.validate({rules:{editPermissionName:{required:!0}}})}));
