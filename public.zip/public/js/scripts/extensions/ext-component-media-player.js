$((function(){"use strict";if($(".video-player"))new Plyr(".video-player",{tooltips:{controls:!0}});if($(".audio-player"))new Plyr(".audio-player")}));
